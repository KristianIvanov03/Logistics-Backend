import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import CompanyRegisterPage from "./components/CompanyRegisterPage";
import RegisterEmployee from "./components/RegisterEmployeePage";
import RegisterCustomer from "./components/RegisterCustomer";
import LoginPage from "./components/LoginPage";
import CompanyDashboard from "./components/CompanyDashboard";
import ClientDashboard from "./components/ClientDashboard";

const App = () => {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Routes>
          <Route path="/register/company" element={<CompanyRegisterPage />} />
          <Route path="/register/employee" element={<RegisterEmployee />} />
          <Route path="/register/clients" element={<RegisterCustomer />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/dashboard/company" element={<CompanyDashboard />} />
          <Route path="/dashboard/client" element={<ClientDashboard />} />
        </Routes>
        
      </div>
    </Router>
  );
};

export default App;
