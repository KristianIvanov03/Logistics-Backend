import { useState, useEffect } from "react";
import { companyApi } from "../services/api";

const CompanyDashboard = () => {
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const data = await companyApi.getProfile();
        setProfile(data);
      } catch (err) {
        setError(err.message);  // Use the enhanced error message
        console.log(err);
      } finally {
        setLoading(false);
      }
      
    };

    loadProfile();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      <h1>Company Profile</h1>
      {profile && (
        <div>
          <p>Name: {profile.name}</p>
          <p>Email: {profile.email}</p>
          {/* Other profile information */}
        </div>
      )}
    </div>
  );
};

export default CompanyDashboard;
