import { useState, useEffect } from "react";
import { clientApi } from "../services/api"; // Import clientApi

const ClientDashboard = () => {
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  // Load the profile on component mount
  useEffect(() => {
    const loadProfile = async () => {
      try {
        const data = await clientApi.getProfile();
        setProfile(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadProfile();
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Client Profile</h1>
      {profile && (
        <div className="mt-4">
          <p><strong>Name:</strong> {profile.name}</p>
          <p><strong>Email:</strong> {profile.email}</p>
          {/* You can display other profile information here */}
        </div>
      )}
    </div>
  );
};

export default ClientDashboard;
